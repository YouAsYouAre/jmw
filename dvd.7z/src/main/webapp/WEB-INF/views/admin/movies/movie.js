/**
 * 
 */

function go_wrt(){
	var form=document.getElementById("prod_form");
	form.action="movie_insert";
	form.submit();
}

function go_search(){
	var form=document.getElementById("prod_form");
	form.action="admin_movie_list";
	form.submit();
}


function go_total(){
	var form=document.getElementById("prod_form");
	document.getElementById("key").value="";
	form.action="admin_movie_list";
	form.submit();	
}


//순익계산--판매가-원가



function go_save(){	
	if(document.getElementById("genre").value==""){
		alert("장르 선택");
		document.getElementById("genre").focus();
		return false;
	}else if(document.getElementById("type").value==""){
		alert("타입선택");
		document.getElementById("type").focus();
		return false;
	}
	else if(document.getElementById("mname").value==""){
		alert("영화이름 입력");
		document.getElementById("mname").focus();
		return false;
	}
	else if(document.getElementById("dtotal").value==""){
		alert("총수량입력");
		document.getElementById("dtotal").focus();
		return false;
	}else if(document.getElementById("dnow").value==""){	
		alert("재고입력");
		document.getElementById("dnow").focus();
		return false;
	}else if(document.getElementById("content").value==""){
		alert("영화 설명 입력");
		document.getElementById("content").focus();
		return false;
	}else {
		var dtotal=parseInt(document.getElementById("dtotal").value);
		var dnow=parseInt(document.getElementById("dnow").value);
if(dtotal<dnow){
		alert("재고가 총수량보다 적습니다 다시입력해주세요");
		document.getElementById("dnow").focus();
		return false;
	}
		else{
		var form=document.getElementById("write_form");
		form.enctype="multipart/form-data";
		form.action="movie_write";
		form.submit();}
	}	
}

function go_detail(mseq){
	var form=document.getElementById("prod_form");
	form.action="admin_movie_detail?mseq="+mseq;
	form.submit();
}

function go_list(){
	var form=document.getElementById("detail_form");
	form.action="admin_movie_list";
	form.submit();
}

function go_mod(mseq){
	var form=document.getElementById("detail_form");
	form.action="admin_movie_update_form?mseq="+mseq;
	form.submit();	
}

function go_mod_save(mseq){
	if(document.getElementById("genre").value==""){
		alert("장르 선택");
		document.getElementById("genre").focus();
		return false;
	}else if(document.getElementById("type").value==""){
		alert("타입선택");
		document.getElementById("type").focus();
		return false;
	}
	else if(document.getElementById("mname").value==""){
		alert("영화이름 입력");
		document.getElementById("mname").focus();
		return false;
	}
	else if(document.getElementById("dtotal").value==""){
		alert("총수량입력");
		document.getElementById("dtotal").focus();
		return false;
	}else if(document.getElementById("dnow").value==""){	
		alert("재고입력");
		document.getElementById("dnow").focus();
		return false;
	}else if(document.getElementById("content").value==""){
		alert("영화 설명 입력");
		document.getElementById("content").focus();
		return false;
	}else {
		var dtotal=parseInt(document.getElementById("dtotal").value);
		var dnow=parseInt(document.getElementById("dnow").value);
if(dtotal<dnow){
		alert("재고가 총수량보다 적습니다 다시입력해주세요");
		document.getElementById("dnow").focus();
		return false;
	}
		else{
		var form=document.getElementById("update_form");
		form.enctype="multipart/form-data";
		form.action="admin_movie_update";
		form.submit();}
	}	
}


function go_actor_save(aseq){
	if(document.getElementById("aname").value==""){
		alert("이름입력");
		document.getElementById("aname").focus();
		return false;
		}else if(document.getElementById("filmo").value==""){
			alert("필모그래피 입력");
			document.getElementById("filmo").focus();
			return false;
		}else var form=document.getElementById("update_form");
	form.enctype="multipart/form-data";
	form.action="admin_actor_update";
	form.submit();
	
}
function go_dtor_save(dlseq){
	if(document.getElementById("dname").value==""){
		alert("이름입력");
		document.getElementById("dname").focus();
		return false;
		}else if(document.getElementById("makes").value==""){
			alert("필모그래피 입력");
			document.getElementById("makes").focus();
			return false;
		}else var form=document.getElementById("update_form");
	form.action="admin_dtor_update";
	form.submit();
	
}

function go_mov(){
	
	var form=document.getElementById("update_form");
	form.action="admin_movie_list";
	form.submit();
}

function actor_mov(){
	
	var form=document.getElementById("write_form");
	form.action="admin_movie_list";
	form.submit();
}

function dtor_mov(){
	
	var form=document.getElementById("write_form");
	form.action="admin_movie_list";
	form.submit();
}


function go_del(mseq){
	 if (!confirm("확인(예) 또는 취소(아니오)를 선택해주세요.")) {
		 var form=document.getElementById("detail_form");
			form.action="admin_movie_list";
			form.submit();
	    } else {
	   
	var form=document.getElementById("detail_form");
	form.action="admin_delete?mseq="+mseq;
	form.submit(); }
}

function newfilmo(){		
		var url="gofilmo";
		window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")	
}
function newmakes(){		
	var url="gomakes";
	window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")	
}


function actor_save(){	
	if(document.getElementById("aname").value==""){
		alert("이름 입력");
		document.getElementById("aname").focus();
		return false;
	}else if(document.getElementById("filmo").value==""){
		alert("필모그래피  입력");
		document.getElementById("filmo").focus();
		return false;
	}else{
		var form=document.getElementById("write_form");
		form.enctype="multipart/form-data";
		form.action="actor_write";
		form.submit();}		
}


function dtor_save(){	
	if(document.getElementById("dname").value==""){
		alert("이름 입력");
		document.getElementById("dname").focus();
		return false;
	}else if(document.getElementById("makes").value==""){
		alert("필모그래피  입력");
		document.getElementById("makes").focus();
		return false;
	}else{
		var form=document.getElementById("write_form");
		form.action="dtor_write";
		form.submit();}		
}


function adddtor(mseq){		
	var url="adddtor?mseq="+mseq;
	window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")	
}

function addactor(mseq){		
	var url="addactor?mseq="+mseq;
	window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")	
}

function plusdtor(){
var form=document.getElementById("detail_form");
form.action="plus_dtors";
form.submit();
}
function plusactor(){
	var form=document.getElementById("detail_form");
	form.action="plus_actors";
	form.submit();
	}

function editdtor(mseq){
	var form=document.getElementById("detail_form");
	form.action="edit_dtors?mseq="+mseq;
	form.submit();
	}
function editactor(mseq){
	var form=document.getElementById("detail_form");
	form.action="edit_actors?mseq="+mseq;
	form.submit();
	}
function enough(mseq){
	opener.location.href="http://localhost:8081/biz/admin_movie_detail?mseq="+mseq;
	self.close();
}

function ac_detail(aseq){
	var form=document.getElementById("prod_form");
	form.action="acdetails?aseq="+aseq;
	form.submit();
}

function dt_detail(dlseq){
	var form=document.getElementById("prod_form");
	form.action="dtdetails?dlseq="+dlseq;
	form.submit();
}
function updateactor(aseq){
	var form=document.getElementById("detail_form");
	form.action="actorupdate?aseq="+aseq;
	form.submit();
}
function updatedtor(dlseq){
	var form=document.getElementById("detail_form");
	form.action="dtorupdate?dlseq="+dlseq;
	form.submit();
}

function updatefilmo(){		
	var url="updatefilmo";
	window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")	
}

function updatemakes(){		
	var url="updatemakes";
	window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")	
}


