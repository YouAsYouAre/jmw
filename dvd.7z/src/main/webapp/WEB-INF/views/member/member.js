
function go_next(){
	if(document.formm.okon1[0].checked==true){//동의함이 선택된 경우
		document.formm.action="join_form"; //요청 url 
		document.formm.submit(); //컨트롤러로 요청
	}else if(document.formm.okon1[1].checked==true){
		alert("약관에 동의해야 회원가입할 수 있음");
	}
	}
	


	
	function go_save(){
		if(document.getElementById("uname").value==""){
			alert("이름을 입력하시오");
			document.getElementById("uname").focus();
			return false;
		}else if(document.getElementById("uphone").value==""){
			alert(" 휴대폰 번호를 입력하시오");
			document.getElementById("uphone").focus();
			return false;	
		}else if(document.getElementById("check").value==""){
			alert(" 중복체크하시오");
			document.getElementById("check").focus();
			return false;	
		}else{
			document.getElementById("join").action="join";
			document.getElementById("join").submit();
		}				
	}
		
	function find_id_form(){
		var url="find_id_form";
		window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")
	}

	function find(){
		if(document.getElementById("uphone").value==""){
			alert("번호를 입력하시오");
			document.getElementById("uphone").focus();
			return false;
		}else {
			var form=document.getElementById("finduname");
			form.action="find_uname";
			form.submit();
		}		
	}
	
	
	function findPassword(){
		if(document.getElementById("name2").value==""){
			alert("이름을 입력해");
			document.getElementById("name2").focus();
			return false;
		}else if(document.getElementById("email2").value==""){
			alert("이메일을 입력해");
			document.getElementById("eamil2").focus();
			return false;
		}else if(document.getElementById("id2").value==""){
			alert("아이디를 입력해");
			document.getElementById("id2").focus();
			return false;
		}else {
			var form=document.getElementById("findPW");
			form.action="find_pwd";
			form.submit();
		}				
	}

	
	
	function changePassword(){
		if(document.getElementById("pwd").value==""){
			alert("바꿀 비번입력"); 
			document.getElementById("pwd").focus;
			return false;
		}else if(document.getElementById("pwdcheck").value!=document.getElementById("pwd").value){
			alert("비번이 일치하지않음"); 
			document.getElementById("pwd").focus;
			return false;
		}else {
			var form=document.getElementById("pwd_form");
			form.action="change_pwd";
			form.submit();
		}		
	}
	
	
	function exit(){
		alert("이미 존재하는 회원입니다");
		document.getElementById("join").action="join";
		document.getElementById("join").submit();
	}
	
	
	function checks(MemberVO){
		var url="check_form?uname="+document.getElementById("uname").value+"&uphone="+document.getElementById("uphone").value;
		window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=450,height=350")
		
	}
	
	
	function findname(){
		var url="finduname";
		window.open(url,"_blank_","toolbar=no, menubar=no,scrollbars=yes,resizable=no, width=550,height=450")
	}
	function findmovie(){
		var form=document.getElementById("fom");
		form.action="find_movie";
		form.submit();
	}

	