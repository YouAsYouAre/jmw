/**
 * 
 */

function deleteQna(){
	var con=confirm("정말 삭제하시겠습니까?");
	if(con==true){	
		var form=document.getElementById("formm");
	form.action="delqna";
	form.submit();}
	
}