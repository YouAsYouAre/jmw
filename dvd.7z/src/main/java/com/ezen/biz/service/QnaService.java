package com.ezen.biz.service;

import java.util.List;

import com.ezen.biz.dto.QnaVO;

public interface QnaService {

	List<QnaVO> selectallQna();

	QnaVO oneqna(int qseq);

	void insertQna(QnaVO vo);

	void deleteQna(int qseq);

}