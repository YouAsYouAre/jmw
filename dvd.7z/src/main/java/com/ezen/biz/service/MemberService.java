package com.ezen.biz.service;

import java.util.List;

import com.ezen.biz.dto.MemberVO;

public interface MemberService {

	MemberVO getMemeber(MemberVO vo);

	void insertMember(MemberVO memberVO);

	void changepwd(MemberVO vo);

	List<MemberVO> listMember(String uname);
	List<MemberVO> allusers();
	void newadmin(MemberVO vo) ;
	MemberVO oneuser(int useq);
	 List<MemberVO>  finduname(String uphone);
	MemberVO ifunameuphone(MemberVO vo);
}