package com.ezen.biz.service;

import java.util.List;

import com.ezen.biz.dto.AnswerVO;

public interface AnswerService {

	void insertAnswer(AnswerVO vo);


	void deleteanswer(int qseq);

	AnswerVO viewanswer(int qseq);
	
	int ifanswer(int qseq) ;
	void updateanswer(AnswerVO vo);

}