package com.ezen.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.CommentDAO;
import com.ezen.biz.dto.CommentVO;

import utils.Criteria;

@Service("commentService")
public class CommentServiceImpl implements CommentService {

	@Autowired
	private CommentDAO cdao;
	
	@Override
	public int saveComment(CommentVO vo) {
		return cdao.saveComment(vo);
	}

	@Override
	public int countCommentList(int mseq) {
		return cdao.countCommentList(mseq);
	}

	@Override
	public List<CommentVO> commentListWithPaging(Criteria criteria, int mseq) {
		return cdao.commentListWithPaging(criteria, mseq);
	}

	@Override
	public int avgrate(CommentVO vo) {
		return cdao.avgrate(vo);
	}

}
