package com.ezen.biz.service;

import java.util.List;

import com.ezen.biz.dto.CommentVO;

import utils.Criteria;

public interface CommentService {

	int saveComment(CommentVO vo);

	int countCommentList(int mseq);

	List<CommentVO> commentListWithPaging(Criteria criteria, int mseq);
	int avgrate(CommentVO vo) ;
}