package com.ezen.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.ActorDAO;
import com.ezen.biz.dto.ActorVO;
@Service("actorService")
public class ActorServiceImpl implements ActorService {

	@Autowired
private ActorDAO adao;
	
	@Override
	public List<ActorVO> allactor() {
		return adao.allactor();
	}

	@Override
	public void inseractor(ActorVO vo) {
adao.inseractor(vo);
	}

	@Override
	public void updatefilmo(ActorVO vo) {
adao.updatefilmo(vo);
	}

	@Override
	public void deleteactor(int aseq) {
adao.deleteactor(aseq);		
	}

	@Override
	public void insertactorlist(ActorVO vo) {
		adao.insertactorlist(vo);
	}

	@Override
	public List<ActorVO> selectoneactorlist(int mseq) {
		return adao.selectoneactorlist(mseq);
	}

	@Override
	public List<ActorVO> getaseq(int mseq) {
		return adao.getaseq(mseq);
	}

	@Override
	public ActorVO actordetail(int aseq) {
		return adao.actordetail(aseq);
	}

	@Override
	public String ifcheck(ActorVO vo) {
		return adao.ifcheck(vo);
	}

	@Override
	public void deleteactorlist(ActorVO vo) {
adao.deleteactorlist(vo);		
	}

	

}
