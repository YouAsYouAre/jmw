package com.ezen.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ezen.biz.dao.AnswerDAO;
import com.ezen.biz.dto.AnswerVO;
@Service("answerService")
public class AnswerServiceImpl implements AnswerService {

	@Autowired
	private AnswerDAO ndao;
	
	@Override
	public void insertAnswer(AnswerVO vo) {
ndao.insertAnswer(vo);
	}



	@Override
	public void deleteanswer(int qseq) {
ndao.deleteanswer(qseq);
	}

	@Override
	public AnswerVO viewanswer(int qseq) {
		return ndao.viewanswer(qseq);
	}

	@Override
	public int ifanswer(int qseq)  {
		return ndao.ifanswer(qseq);
	}



	@Override
	public void updateanswer(AnswerVO vo) {
ndao.updateanswer(vo);		
	}

	
	
}
