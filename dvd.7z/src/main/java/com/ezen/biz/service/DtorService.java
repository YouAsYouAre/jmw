package com.ezen.biz.service;

import java.util.List;

import com.ezen.biz.dto.DtorVO;

public interface DtorService {

	void insertdtor(DtorVO vo);

	List<DtorVO> selectdtor(int mseq);

	void addmakes(DtorVO vo);

	void deletedtor(DtorVO vo);
	void newdtorlist(DtorVO vo);
	List<DtorVO> alldtorlist() ;
	DtorVO selectdetaildtor(int dlseq);
	String ifcheck(DtorVO vo);
}