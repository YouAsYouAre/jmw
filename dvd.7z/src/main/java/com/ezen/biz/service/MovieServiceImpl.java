package com.ezen.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.MemberDAO;
import com.ezen.biz.dao.MovieDAO;
import com.ezen.biz.dto.ActorVO;
import com.ezen.biz.dto.MemberVO;
import com.ezen.biz.dto.MovieVO;

import utils.Criteria;
@Service("movieService")
public class MovieServiceImpl implements MovieService{
	@Autowired
	private MovieDAO mdao;

	@Override
	public List<MovieVO> selectmovielist() {
		return mdao.selectmovielist();
	}

	@Override
	public MovieVO selectonemovie(int mseq) {
		return mdao.selectonemovie(mseq);
	}

	@Override
	public void updatemovie(MovieVO vo) {
mdao.updatemovie(vo);		
	}

	@Override
	public List<MovieVO> selectmovielistkind(int kind) {
		return mdao.selectmovielistkind(kind);
	}

	@Override
	public List<ActorVO> getMovieActors(int mseq) {
		return mdao.movieactors(mseq);
	}

	@Override
	public List<MovieVO> findgenre(MovieVO vo) {
		return mdao.findgenre(vo);
	}

	@Override
	public List<MovieVO> selectwes() {
		return mdao.selectwes();
	}

	@Override
	public List<MovieVO> selectkorea() {
		return mdao.selectkorea();
	}

	@Override
	public void insermovie(MovieVO vo) {
		 mdao.insermovie(vo);		
	}

	@Override
	public List<MovieVO> selectallmovie(String mname) {
		return mdao.selectallmovie(mname);
	}

	@Override
	public void deletemovie(int mseq) {
mdao.deletemovie(mseq);		
	}

	@Override
	public List<MovieVO> typemovie(String type) {
		return mdao.typemovie(type);
	}

	

	@Override
	public List<MovieVO> listMovieWithPaging(String mname, Criteria cri) {
		return mdao.listMovieWithPaging(mname, cri);
	}

	@Override
	public int countMovieList(String mname) {
		return mdao.countMovieList(mname);
	}

	@Override
	public List<MovieVO> rateview(MovieVO vo) {
		return mdao.rateview(vo);
	}

	
	
	
}
