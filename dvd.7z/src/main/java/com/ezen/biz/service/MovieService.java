package com.ezen.biz.service;

import java.util.List;

import com.ezen.biz.dto.ActorVO;
import com.ezen.biz.dto.MovieVO;

import utils.Criteria;

public interface MovieService {

	List<MovieVO> selectmovielist();

	MovieVO selectonemovie(int mseq);

	void updatemovie(MovieVO vo);
	List<MovieVO>selectmovielistkind(int kind);
	List<ActorVO> getMovieActors(int mseq);
	List<MovieVO> findgenre(MovieVO vo);
	List<MovieVO> selectwes();
	 List<MovieVO> selectkorea();
	 void insermovie(MovieVO vo);
	 List<MovieVO>selectallmovie(String mname);
	 void deletemovie(int mseq);
	 List<MovieVO>typemovie(String type);
	 List<MovieVO>listMovieWithPaging(String mname,Criteria cri);
	 int countMovieList(String mname) ;
	 List<MovieVO>rateview(MovieVO vo);
}