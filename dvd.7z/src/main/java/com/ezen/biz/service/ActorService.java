package com.ezen.biz.service;

import java.util.List;

import com.ezen.biz.dto.ActorVO;

public interface ActorService {

	List<ActorVO> allactor();

	void inseractor(ActorVO vo);

	void updatefilmo(ActorVO vo);
	void deleteactor(int aseq);
	void insertactorlist(ActorVO vo);
	 List<ActorVO> selectoneactorlist(int mseq);
	 List<ActorVO> getaseq(int mseq);
	 ActorVO actordetail(int aseq);
	 String ifcheck(ActorVO vo);
	 void deleteactorlist(ActorVO vo);

}