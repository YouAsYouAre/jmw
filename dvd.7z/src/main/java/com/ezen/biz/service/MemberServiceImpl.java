package com.ezen.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.MemberDAO;
import com.ezen.biz.dto.MemberVO;

import utils.Criteria;
@Service("memberService")
public class MemberServiceImpl implements MemberService{
	@Autowired
	private MemberDAO mdao;

	@Override
	public MemberVO getMemeber(MemberVO vo) {
		return mdao.getMemeber(vo);
	}


	@Override
	public void insertMember(MemberVO memberVO) {
mdao.insertMember(memberVO);		
	}

	@Override
	public void changepwd(MemberVO vo) {
mdao.changepwd(vo);		
	}

	@Override
	public List<MemberVO> listMember(String uname) {
		return mdao.listMember(uname);
	}


	@Override
	public List<MemberVO> allusers() {
		return mdao.allusers();
	}


	@Override
	public void newadmin(MemberVO vo) {
mdao.newadmin(vo);		
	}


	@Override
	public MemberVO oneuser(int useq) {
		return mdao.oneuser(useq);
	}

	@Override
	public MemberVO ifunameuphone(MemberVO vo) {
		return mdao.ifunameuphone(vo);
	}


	@Override
	public  List<MemberVO> finduname(String uphone) {
		return mdao.finduname(uphone);
	}
	
	
	
}
