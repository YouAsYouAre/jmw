package com.ezen.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.DtorDAO;
import com.ezen.biz.dto.DtorVO;
@Service("dtorService")
public class DtorServiceImpl implements DtorService {

	@Autowired
private DtorDAO ddao;
	
	@Override
	public void insertdtor(DtorVO vo) {
ddao.insertdtor(vo);
	}

	@Override
	public List<DtorVO> selectdtor(int mseq) {
		return ddao.selectdtor(mseq);
	}

	@Override
	public void addmakes(DtorVO vo) {
ddao.addmakes(vo);
	}

	@Override
	public void deletedtor(DtorVO vo) {
ddao.deletedtor(vo);
	}

	@Override
	public void newdtorlist(DtorVO vo) {
ddao.newdtorlist(vo);		
	}

	@Override
	public List<DtorVO> alldtorlist() {
		return ddao.alldtorlist();
	}

	@Override
	public DtorVO selectdetaildtor(int dlseq) {
		return ddao.selectdetaildtor(dlseq);
	}

	@Override
	public String ifcheck(DtorVO vo) {
		return ddao.ifcheck(vo);
	}

}
