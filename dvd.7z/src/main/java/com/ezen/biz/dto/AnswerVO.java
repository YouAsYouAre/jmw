package com.ezen.biz.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AnswerVO {
private int nseq;
private String content;
private int qseq;
}
