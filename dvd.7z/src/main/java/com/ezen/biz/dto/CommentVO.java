package com.ezen.biz.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class CommentVO {

	private int cseq;
	private int mseq;
	private Date reg_date;
	private String comments;
	private String writer;
	private int rate;
}
