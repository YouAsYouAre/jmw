package com.ezen.biz.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class QnaVO {
private int qseq ;
private int useq;
private String title;
private String content;
private int rep;

}
