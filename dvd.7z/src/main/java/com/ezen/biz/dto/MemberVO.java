package com.ezen.biz.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MemberVO {
	private int useq;
	private String uname;
	private String uphone;
	private int admin;
	
	
}
