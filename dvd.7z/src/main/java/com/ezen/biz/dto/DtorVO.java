package com.ezen.biz.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DtorVO {
	private int dseq;
	private String dname;
	private int mseq;
private String makes;
	private int dlseq;
	
}
