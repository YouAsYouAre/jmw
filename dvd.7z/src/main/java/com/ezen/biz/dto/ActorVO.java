package com.ezen.biz.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ActorVO {
	private int aseq;
	private String aname;
private String aimage;
public String filmo;
	private int alseq;
	private int mseq;
	
}
