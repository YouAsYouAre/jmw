package com.ezen.biz.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MovieVO {
	private int mseq;
	private String mname;
	private String mimage;
	private String genre;
	private String content;
	private int dtotal;
	private int dnow;
	private String type;
	
	
}
