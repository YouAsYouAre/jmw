package com.ezen.biz.dao;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.CommentVO;
import utils.Criteria;

@Repository
public class CommentDAO {

	@Autowired
	private SqlSessionTemplate mybatis;
	
	
	public int saveComment(CommentVO vo) {
	return	mybatis.insert("CommentMapper.saveComment",vo);
	}
	
	public int countCommentList(int mseq) {
		
		return mybatis.selectOne("CommentMapper.countCommentList",mseq);
	}
	
	
	public List<CommentVO> commentListWithPaging(Criteria criteria, int mseq) {
		HashMap<String, Object> map = new HashMap<>();
		
		map.put("criteria", criteria);
		map.put("mseq", mseq);
		
		return mybatis.selectList("CommentMapper.commentListWithPaging", map);
	}
	
	public int avgrate(CommentVO vo) {
		return mybatis.selectOne("CommentMapper.avgrate",vo);
	}
	
	
}
