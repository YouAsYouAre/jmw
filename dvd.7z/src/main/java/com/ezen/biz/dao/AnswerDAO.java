package com.ezen.biz.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.AnswerVO;
@Repository
public class AnswerDAO  {
	@Autowired
	private SqlSessionTemplate mybatis;


	public void insertAnswer(AnswerVO vo) {
		mybatis.insert("AnswerMapper.insertAnswer",vo);
	}
	
	
	
	
	
	public void deleteanswer(int qseq) {
		mybatis.delete("AnswerMapper.deleteanswer",qseq);
	}
	
	
	public AnswerVO viewanswer(int qseq) {
		return mybatis.selectOne("AnswerMapper.viewanswer",qseq);
	}
	
	public int ifanswer(int qseq) {
		return mybatis.selectOne("AnswerMapper.ifanswer",qseq);
	}
	
	public void updateanswer(AnswerVO vo) {
		mybatis.update("AnswerMapper.updateanswer",vo);
	}
}
