package com.ezen.biz.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ezen.biz.dto.DtorVO;

@Repository
public class DtorDAO{
	@Autowired
	private SqlSessionTemplate mybatis;
//회원이름으로 정보조회
	
	public void newdtorlist(DtorVO vo) {
		mybatis.insert("DtorMapper.newdtorlist",vo);
	}
	public void insertdtor(DtorVO vo) {
		mybatis.insert("DtorMapper.insertdtor",vo);		
	}
	
	
	public List<DtorVO> selectdtor(int mseq) {
	return	mybatis.selectList("DtorMapper.selectdtor",mseq);	
	}
	
	
	
	public void addmakes(DtorVO vo) {
		mybatis.update("DtorMapper.addmakes",vo);
	}
	
	
	public void deletedtor(DtorVO vo) {
		mybatis.delete("DtorMapper.deletedtor",vo);
	}
	
	public List<DtorVO> alldtorlist() {
	return	mybatis.selectList("DtorMapper.alldtorlist");
	}
	public DtorVO selectdetaildtor(int dlseq) {
		return mybatis.selectOne("DtorMapper.selectdetaildtor",dlseq);
	}
	
	public String ifcheck(DtorVO vo) {
		return mybatis.selectOne("DtorMapper.ifcheck",vo);
	}
}
