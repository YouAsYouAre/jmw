package com.ezen.biz.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.ActorVO;
import com.ezen.biz.dto.DtorVO;

@Repository
public class ActorDAO {
	@Autowired
	private SqlSessionTemplate mybatis;
//회원이름으로 정보조회
	
	public List<ActorVO> allactor() {
		return mybatis.selectList("ActorMapper.allactor");
	}
	
	
	public void inseractor(ActorVO vo) {		
		mybatis.insert("ActorMapper.inseractor",vo);
	}
	
	public void updatefilmo(ActorVO vo) {
		mybatis.update("ActorMapper.updatefilmo",vo);
	}
	
	public void deleteactor(int aseq) {
		mybatis.delete("ActorMapper.deleteactor",aseq);
	}
	
	public void insertactorlist(ActorVO vo) {
		mybatis.insert("ActorMapper.insertactorlist",vo);
	}
	public List<ActorVO> selectoneactorlist(int mseq) {
		return mybatis.selectList("ActorMapper.selectoneactorlist",mseq);
	}
	public List<ActorVO> getaseq(int mseq){
		return mybatis.selectList("ActorMapper.getaseq",mseq);
	}
	
	public ActorVO actordetail(int aseq) {
		return mybatis.selectOne("ActorMapper.actordetail",aseq);
	}
	public String ifcheck(ActorVO vo) {
		return mybatis.selectOne("ActorMapper.ifcheck",vo);
	}
	
	public void deleteactorlist(ActorVO vo) {
		 mybatis.delete("ActorMapper.deleteactorlist",vo);
	}
}
