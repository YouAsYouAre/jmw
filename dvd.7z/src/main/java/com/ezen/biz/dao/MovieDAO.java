package com.ezen.biz.dao;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.ActorVO;
import com.ezen.biz.dto.MovieVO;

import utils.Criteria;

@Repository
public class MovieDAO  {
	@Autowired
	private SqlSessionTemplate mybatis;

	
	public List<MovieVO> selectmovielist() {			
		 return mybatis.selectList("MovieMapper.selectmovielist");
	}
	
	
	public MovieVO selectonemovie(int mseq) {
		return mybatis.selectOne("MovieMapper.selectonemovie",mseq);	
	}
	
	
	public void updatemovie(MovieVO vo) {
		mybatis.update("MovieMapper.updatemovie",vo);
	}
	
	public List<MovieVO>selectmovielistkind(int kind){
		return mybatis.selectList("MovieMapper.selectmovielistkind",kind);
	}
	
	public List<ActorVO> movieactors(int mseq){
		return mybatis.selectList("MovieMapper.movieactors",mseq);
	}
	
	
	public List<MovieVO> findgenre(MovieVO vo){
		return mybatis.selectList("MovieMapper.findgenre",vo);
	}
	public List<MovieVO> selectwes(){
		return mybatis.selectList("MovieMapper.selectwes");
	}
	public List<MovieVO> selectkorea(){
		return mybatis.selectList("MovieMapper.selectkorea");
	}
	
	public void insermovie(MovieVO vo) {
		 mybatis.insert("MovieMapper.insertmovie",vo);		
	}
	
	public List<MovieVO>selectallmovie(String mname){
		return mybatis.selectList("MovieMapper.selectallmovie",mname);
	}
	
	public void deletemovie(int mseq) {
		mybatis.delete("MovieMapper.deletemovie",mseq);
	}
	public List<MovieVO>typemovie(String type){
		return mybatis.selectList("MovieMapper.typemovie",type);
	}
	
	
	public List<MovieVO>listMovieWithPaging(String mname,Criteria cri){
		HashMap<String, Object>map=new HashMap<>();
		map.put("cri", cri);
		map.put("mname", mname);
		return mybatis.selectList("MovieMapper.listMovieWithPaging",map);
	}
	
	public int countMovieList(String mname) {
		return mybatis.selectOne("MovieMapper.countMovieList",mname);
	}
	
	
	public List<MovieVO>rateview(MovieVO vo){
		return mybatis.selectList("MovieMapper.rateview",vo);		
	}
}
