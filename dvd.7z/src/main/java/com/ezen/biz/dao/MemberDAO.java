package com.ezen.biz.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ezen.biz.dto.MemberVO;

@Repository
public class MemberDAO {
	@Autowired
	private SqlSessionTemplate mybatis;
//회원이름으로 정보조회
	public MemberVO getMemeber(MemberVO vo) {			
		 return mybatis.selectOne("MemberMapper.getMember", vo);
	}
	
	//회원가입
	
	public void insertMember(MemberVO memberVO) {	
		mybatis.insert("MemberMapper.insertMember", memberVO);
	}
	
	
	//정보수정
	
	public void changepwd(MemberVO vo) {
		mybatis.update("MemberMapper.changepwd",vo);
	}
	
	//회원리스트
	public List<MemberVO> listMember(String uname){
		return mybatis.selectList("MemberMapper.listMember",uname);
	}
	
	
	public List<MemberVO> allusers(){
		return mybatis.selectList("MemberMapper.allusers");
	}
	
	public void newadmin(MemberVO vo) {
		
		mybatis.update("MemberMapper.newadmin",vo);
	}
	
	public MemberVO oneuser(int useq) {
		
		return mybatis.selectOne("MemberMapper.oneuser",useq);
	}
	
	public MemberVO ifunameuphone(MemberVO vo) {
		return mybatis.selectOne("MemberMapper.ifunameuphone",vo);		
	}
	public List<MemberVO>  finduname(String uphone) {
		return mybatis.selectList("MemberMapper.finduname",uphone);
	}
	
}
