package com.ezen.view;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import com.ezen.biz.dto.MemberVO;
import com.ezen.biz.dto.MovieVO;
import com.ezen.biz.service.MemberService;
import com.ezen.biz.service.MovieService;

import utils.Criteria;
import utils.PageMaker;

@Controller
@SessionAttributes("loginUser")
public class MemberController {

	@Autowired
	private MemberService memberService;
	@Autowired
	private MovieService movieService;
	
	
	@GetMapping("/finduname")
	public String finduname() {
		return "member/finduname";
	}	
	@GetMapping("/contract")
	public String contractView() {
		return "member/contract";
	}
	@PostMapping("/join_form")
	public String joinView() {
		return "member/join";

	}
	
	@PostMapping("/login")
	public String loginaction(MemberVO vo,Model model) {
		
	MemberVO v=memberService.getMemeber(vo);
	if(v.getAdmin()==1) {  
			 model.addAttribute("loginUser",v);
			

		return "redirect:admin_movie_list";
			}
	else {
		 model.addAttribute("loginUser",v);
			return "redirect:index";}
	
	}
	
	/*@RequestMapping("/admin_movie_list")
	public String adminList(Model model,
			@RequestParam(value="key",defaultValue ="") String mname) {
System.out.println(mname);
		List<MovieVO>list= movieService.selectallmovie(mname);
		model.addAttribute("list",list);
		return "admin/movies/movieList";
		
	}*/
	@RequestMapping("/admin_movie_list")
	public String adminmovieList(@RequestParam(value="pageNum", defaultValue="1") String pageNum,
			@RequestParam(value="rowsPerPage",defaultValue = "10") String rowsPerPage,
			@RequestParam(value="key",defaultValue ="") String mname,Criteria criteria,Model model){	
		List<MovieVO>list= movieService.listMovieWithPaging(mname, criteria);
	
	 PageMaker pm=new PageMaker();
	pm.setCriteria(criteria);
	pm.setTotalCount(movieService.countMovieList(mname));
	model.addAttribute("list",list);
	model.addAttribute("movieListSize",list.size());
	model.addAttribute("pageMaker", pm);
		return "admin/movies/movieList";
		
}
	
	@GetMapping("/login_form")
	public String loginView() {
		return "member/login";
	}
	
	  
	
	
	@GetMapping("/logout")
	public String logout( SessionStatus status) {
		status.setComplete();
		return "member/login";
	}
	
	
	
	

	@RequestMapping("/admin_member_list")
	public String adminMemberList(Model model) {
	List<MemberVO>list=memberService.allusers();
	model.addAttribute("memberList",list);
		return "admin/member/memberList"; 
		
	}
	
	@RequestMapping("/admin_make")
	public String newadmin(MemberVO vo,Model model) {
	MemberVO v=	memberService.oneuser(vo.getUseq());
		model.addAttribute("vo",vo);
		model.addAttribute("v",v);
		return "admin/member/memberDetail";
	}
	
	@RequestMapping("/admin_make_action")
	public String adminMakeACtion(MemberVO vo) {
		memberService.newadmin(vo);
		return "redirect:admin_member_list";
	}

	@GetMapping("/admin_logout")
	public String adminLogout(SessionStatus status) {		
		status.setComplete();
		return "member/login";
		
	}
	
	
	@RequestMapping("/check_form")
	public String checkaction(MemberVO vo,Model model) {
		if(memberService.ifunameuphone(vo)!=null){
		 model.addAttribute("uname",vo.getUname());
		 model.addAttribute("uphone",vo.getUphone());
			model.addAttribute("message",1);}
else {
	 model.addAttribute("uname",vo.getUname());
	 model.addAttribute("uphone",vo.getUphone());
	model.addAttribute("message",-1);}
		 return "member/check";
	}
	
	
	@RequestMapping("/join")
	public String newmember(MemberVO vo) {
		memberService.insertMember(vo);
		return "member/login";
		
	}
	
	
	@PostMapping("/find_uname")
	public String findIdAction(MemberVO vo,Model model) {
		System.out.println("폰번======"+vo.getUphone());
		 List<MemberVO> list=memberService.finduname(vo.getUphone());
		 if(list!=null) {//아이디 조회성공
			 model.addAttribute("message",1);
			 model.addAttribute("list",list);		 
		 }else {
			 model.addAttribute("message",-1);
		 }
		return "member/findResult"; //아이디 조회결과 화면요청
	}
	
	
}
