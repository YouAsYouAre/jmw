package com.ezen.view;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ezen.biz.dto.ActorVO;
import com.ezen.biz.dto.DtorVO;
import com.ezen.biz.dto.MovieVO;
import com.ezen.biz.service.ActorService;
import com.ezen.biz.service.DtorService;
import com.ezen.biz.service.MovieService;

@Controller
@SessionAttributes("loginUser")
public class movieController {

	@Autowired
	private ActorService actorService;
	@Autowired
	private MovieService movieService;
	@Autowired
	private DtorService dtorService;

	@RequestMapping(value = "/movie_detail", method = RequestMethod.GET)
	public String moviedetail(MovieVO vo, Model model, ActorVO avo) {
		// System.out.println("moviedetail: vo="+ vo);
		MovieVO mv = movieService.selectonemovie(vo.getMseq());

		List<ActorVO> list = actorService.selectoneactorlist(vo.getMseq());

		List<DtorVO> dlist = dtorService.selectdtor(vo.getMseq());
		model.addAttribute("dlist", dlist);
		model.addAttribute("list", list);
		model.addAttribute("mv", mv);
		return "movie/movieDetail";
	}
@RequestMapping("types")
public String types(@RequestParam(value="type")String type,Model model) {
	List<MovieVO>list=movieService.typemovie(type);
	
			model.addAttribute("moviegenre",list);
		
	return "movie/movieGenre";
}
	
	
	
	@RequestMapping("/genre")
	public String findgenre(MovieVO vo, Model model) {
		List<MovieVO> moviegenre = movieService.findgenre(vo);
		model.addAttribute("moviegenre", moviegenre);
		return "movie/movieGenre";

	}

	@PostMapping("/movie_insert")
	public String insertgo() {
		return "admin/movies/insertmovie";
	}

	@PostMapping("/movie_write")
	public String adminMovieWrite(MovieVO vo, HttpSession session,
			@RequestParam(value = "movie_image") MultipartFile uploadFile) {
		if (!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			vo.setMimage(fileName); // 데이터베이스에 저장할 용도
			// 전송된 파일을 이동할 실제 경로
			String image_path = session.getServletContext().getRealPath("WEB-INF/resources/movie_images/");

			try {
				uploadFile.transferTo(new File(image_path + fileName));
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		}
		movieService.insermovie(vo);

		return "redirect:admin_movie_list";
	}

	@RequestMapping("/admin_movie_detail")
	public String detailgo(@RequestParam(value = "mseq")  int mseq, Model model) {
		MovieVO vo = movieService.selectonemovie(mseq);
		List<ActorVO> avo = actorService.selectoneactorlist(mseq);
		List<DtorVO> dvo = dtorService.selectdtor(mseq);
		model.addAttribute("vo", vo);
		model.addAttribute("avo", avo);
		model.addAttribute("dvo", dvo);

		return "admin/movies/movieDetail";

	}

	@RequestMapping("/admin_movie_update_form")
	public String adminMovieUpdateView(MovieVO vo, Model model) {
		MovieVO mvo = movieService.selectonemovie(vo.getMseq());
		List<ActorVO> avo = actorService.selectoneactorlist(vo.getMseq());
		List<DtorVO> dvo = dtorService.selectdtor(vo.getMseq());
		model.addAttribute("avo", avo);
		model.addAttribute("dvo", dvo);
		model.addAttribute("mvo", mvo);
		return "admin/movies/movieUpdate";
	}

	@PostMapping("/admin_movie_update")
	public String adminmovieUpdate(MovieVO vo, DtorVO dvo, ActorVO avo,
			@RequestParam(value = "movie_image") MultipartFile uploadFile,
			@RequestParam(value = "nonmakeImg") String org_image, HttpSession session) {

		if (!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			vo.setMimage(fileName);
			; // 데이터베이스에 저장할 용도
			// 전송된 파일을 이동할 실제 경로
			String image_path = session.getServletContext().getRealPath("WEB-INF/resources/movie_images/");
			try {
				uploadFile.transferTo(new File(image_path + fileName));
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		} else {
			// 상품의 기본이미지
			vo.setMimage(org_image);
		}
		movieService.updatemovie(vo);

		return "redirect:admin_movie_list";
	}

	@RequestMapping("/admin_delete")
	public String deleteAction(int mseq) {
		movieService.deletemovie(mseq);
		return "redirect:admin_movie_list";
	}

	@RequestMapping("/admin_newactor")
	public String newactor() {
		return "admin/actor/actorwrite";
	}

	@RequestMapping("/admin_newdtor")
	public String newdtor() {
		return "admin/dtor/dtorwrite";
	}

	@RequestMapping("/gofilmo")
	public String getfilmo() {
		return "admin/actor/newfilmo";
	}

	@RequestMapping("/gomakes")
	public String getmakes() {
		return "admin/dtor/newmakes";
	}

	@PostMapping("/actor_write")
	public String actormake(ActorVO vo, HttpSession session,
			@RequestParam(value = "actor_image") MultipartFile uploadFile) {
		if (!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			vo.setAimage(fileName); // 데이터베이스에 저장할 용도
			// 전송된 파일을 이동할 실제 경로
			String image_path = session.getServletContext().getRealPath("WEB-INF/resources/images/");

			try {
				uploadFile.transferTo(new File(image_path + fileName));
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println(vo.getFilmo());
		actorService.inseractor(vo);
		return "redirect:admin_movie_list";
	}

	@PostMapping("/dtor_write")
	public String adddtor(DtorVO vo, HttpSession session) {
		dtorService.newdtorlist(vo);
		return "redirect:admin_movie_list";
	}

	@RequestMapping("/adddtor")
	public String adddtoraction(@RequestParam(value = "mseq") int mseq, Model model) {
		List<DtorVO> list = dtorService.alldtorlist();
		model.addAttribute("list", list);
		model.addAttribute("mseq", mseq);
		return "admin/dtor/dtorlist";
	}
	
	@RequestMapping("/addactor")
	public String addactoraction(@RequestParam(value = "mseq") int mseq, Model model) {
		List<ActorVO> list = actorService.allactor();
		model.addAttribute("list", list);
		model.addAttribute("mseq", mseq);
		return "admin/actor/actorlist";
	}

	@RequestMapping("/plus_dtors")
	public String plustdtor(DtorVO vo, RedirectAttributes rattr) {		
		if(dtorService.ifcheck(vo)==null)dtorService.insertdtor(vo);	
		rattr.addAttribute("mseq", vo.getMseq());
		return "redirect:adddtor";
	}
	@RequestMapping("/plus_actors")
	public String plustactor(ActorVO vo, RedirectAttributes rattr) {		
		if(actorService.ifcheck(vo)==null)actorService.insertactorlist(vo);
		rattr.addAttribute("mseq", vo.getMseq());
		return "redirect:addactor";
	}

	@RequestMapping("/edit_dtors")
	public String editdtor(DtorVO vo,RedirectAttributes rattr) {
		if(dtorService.ifcheck(vo)!=null)dtorService.deletedtor(vo);
		rattr.addAttribute("mseq", vo.getMseq());

		return "redirect:adddtor";
	}
	@RequestMapping("/edit_actors")
	public String editactor(ActorVO vo,RedirectAttributes rattr) {
		if(actorService.ifcheck(vo)!=null)actorService.deleteactorlist(vo);
		rattr.addAttribute("mseq", vo.getMseq());

		return "redirect:addactor";
	}
	
	@RequestMapping("/dtor_detail")
	public String dtordetail(int dlseq, Model model, int mseq) {
		DtorVO vo = dtorService.selectdetaildtor(dlseq);
		model.addAttribute("vo", vo);
		model.addAttribute("mseq", mseq);
		return "admin/dtor/dtordetail";
	}

	@RequestMapping("/actor_detail")
	public String actordetail(int aseq, Model model, int mseq) {
		ActorVO vo = actorService.actordetail(aseq);
		model.addAttribute("vo", vo);
		model.addAttribute("mseq", mseq);
		return "admin/actor/actordetail";
	}
	
	
	@RequestMapping("/admin_allactor")
	public String allactor(Model model) {
		List<ActorVO> list = actorService.allactor();
		model.addAttribute("list", list);
		return "admin/actor/Allactorlist";
	}
	
	@RequestMapping("/acdetails")
	public String actordetails(int aseq,Model model) {
	ActorVO vo=	actorService.actordetail(aseq);
		model.addAttribute("vo",vo);
		return "admin/actor/actordetail2";
	}
	@RequestMapping("/dtdetails")
	public String dtordetails(int dlseq,Model model) {
	DtorVO vo=	dtorService.selectdetaildtor(dlseq);
		model.addAttribute("vo",vo);
		return "admin/dtor/dtordetail2";
	}
	
	@RequestMapping("/actorupdate")
	public String actorupdate(int aseq,Model model) {
		ActorVO vo=	actorService.actordetail(aseq);
		model.addAttribute("vo",vo);
		return "admin/actor/actorUpdate";
	}
	@RequestMapping("/dtorupdate")
	public String dtorupdate(int dlseq,Model model) {
		DtorVO vo=	dtorService.selectdetaildtor(dlseq);
		model.addAttribute("vo",vo);
		return "admin/dtor/dtorUpdate";
	}
	
	@RequestMapping("/admin_actor_update")
	public String actorUpdate(ActorVO vo,
			@RequestParam(value = "actor_image") MultipartFile uploadFile,
			@RequestParam(value = "nonmakeImg") String org_image, HttpSession session) {

		if (!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			vo.setAimage(fileName);
			; // 데이터베이스에 저장할 용도
			// 전송된 파일을 이동할 실제 경로
			String image_path = session.getServletContext().getRealPath("WEB-INF/resources/images/");
			try {
				uploadFile.transferTo(new File(image_path + fileName));
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		} else {
			// 상품의 기본이미지
			vo.setAimage(org_image);
		}
		actorService.updatefilmo(vo);

		return "redirect:admin_allactor";
	}
	
	@RequestMapping("/updatefilmo")
	public String updatefilmoaction() {
		return "admin/actor/updatefilmo";
	}
	@RequestMapping("/updatemakes")
	public String updatemakesaction() {
		return "admin/dtor/updatemakes";
	}
	
	@RequestMapping("/admin_alldtor")
	public String alldtor(Model model) {
		List<DtorVO> list = dtorService.alldtorlist();
		System.out.println(list.toString());
		model.addAttribute("list", list);
		return "admin/dtor/Alldtorlist";
	}
	
	@RequestMapping("/admin_dtor_update")
	public String dtorupdate(int dlseq,DtorVO vo) {
		dtorService.addmakes(vo);
		return "redirect:admin_alldtor";
	}
	
	
	@RequestMapping("/find_movie")
	public String findMovie(@RequestParam(value = "key", defaultValue="") String mname,Model model) {
	List<MovieVO> list=movieService.selectallmovie(mname);
	model.addAttribute("moviegenre",list);
	return "movie/movieGenre";
	}
	
@RequestMapping("/actors_delete")
public String actorsDel(int aseq) {
	actorService.deleteactor(aseq);
	return "redirect:admin_allactor";
	
}



}

