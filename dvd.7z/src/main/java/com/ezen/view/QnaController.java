package com.ezen.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.biz.dto.AnswerVO;
import com.ezen.biz.dto.MemberVO;
import com.ezen.biz.dto.QnaVO;
import com.ezen.biz.service.AnswerService;
import com.ezen.biz.service.QnaService;

@Controller
public class QnaController {

	@Autowired
	private QnaService qnaService;
	@Autowired
	private AnswerService answerService;
	
	//특정회원의 qna목록조회
	@GetMapping("/qna_list")
	public String qnaList(HttpSession session,Model model) {
		MemberVO loginUser=(MemberVO) session.getAttribute("loginUser");
		if(loginUser==null) {//로그인이 안된경우
			return "member/login";
		}else {
		String id=loginUser.getUname();
	List<QnaVO>qnaList=	qnaService.selectallQna();
	int result=0;
	for(int i=0; i<qnaList.size(); i++) {
		 result= answerService.ifanswer(qnaList.get(i).getQseq());
		 qnaList.get(i).setRep(result);
				}
		model.addAttribute("qnaList",qnaList);
		
	
		
		return "qna/qnaList";
	
		}
		
	}
	
	
	
	//qna게시글 상세보기
	@GetMapping("/qna_view")
	public String qnaview(Model model,HttpSession session,QnaVO qvo) {
		MemberVO loginUser=(MemberVO) session.getAttribute("loginUser");
		if(loginUser==null) {//로그인이 안된경우
			return "member/login";
		}else {
			
			int qseq=qvo.getQseq();
			
			QnaVO vo=qnaService.oneqna(qseq);
			model.addAttribute("qnaVO",vo);
			AnswerVO avo=new AnswerVO();
			
			int result =  answerService.ifanswer(qseq);
if(result == 0)avo.setContent("아직 답변이 없습니다");
else {avo=answerService.viewanswer(qseq);}
			
			model.addAttribute("avo",avo);
		return "qna/qnaView";
		}
	}
	
	
	@GetMapping("/qna_write_form")
	public String qnaWriteView(HttpSession session) {	
		MemberVO loginUser=(MemberVO) session.getAttribute("loginUser");
		if(loginUser==null) {//로그인이 안된경우
			return "member/login";
		}else {
		return "qna/qnaWrite";
		}
	}
	
	
	@PostMapping("/qna_write")
	public String qnaWriteAction(QnaVO vo,HttpSession session) {
		MemberVO loginUser=(MemberVO) session.getAttribute("loginUser");
		if(loginUser==null) {//로그인이 안된경우
			return "member/login";
		}else {
		
		vo.setUseq(loginUser.getUseq());
		System.out.println(loginUser.getUname()+"이름");
		System.out.println(loginUser.getUseq()+"번호");

		System.out.println("useq:"+vo.getUseq());
		qnaService.insertQna(vo);
		return "redirect:qna_list";
		}
	}
	
	@RequestMapping("/delqna")
	public String delqna(QnaVO vo) {
		if(answerService.ifanswer(vo.getQseq())!=0)	{
				answerService.deleteanswer(vo.getQseq());
				qnaService.deleteQna(vo.getQseq());
		}else 
		qnaService.deleteQna(vo.getQseq());
		System.out.println(vo.getQseq()+":qseq");
		System.out.println("수행됨");
		return "redirect:qna_list";
		
	}
	
	
	@RequestMapping("/admin_qna_list")
	public String adminQnaListgo(Model model) {
		
		List<QnaVO>qnaList=	qnaService.selectallQna();
		
		int result =0;
		String rp=null;
		for(int i=0; i<qnaList.size(); i++) {
	result=answerService.ifanswer(qnaList.get(i).getQseq());
	qnaList.get(i).setRep(result);
		}
		model.addAttribute("qnaList",qnaList);		
		return "admin/qna/qnaList";
	}
	
	@RequestMapping("/admin_qna_detail")
	public String adminQnaDetail(int qseq,Model model) {
		QnaVO vo=qnaService.oneqna(qseq);
		model.addAttribute("vo",vo);
		AnswerVO avo=new AnswerVO();
		if(answerService.ifanswer(qseq)!=0) {
			 avo=answerService.viewanswer(qseq);
			 }
		model.addAttribute("avo",avo);
		
		return "admin/qna/qnaDetail";
	}
	
	@RequestMapping("/admin_answersave")
	public String answerSave(int qseq,AnswerVO vo) {
		answerService.insertAnswer(vo);
		return "redirect:admin_qna_list";
	}
	@RequestMapping("/admin_answerupdate")
	public String answerUpdate(int qseq,AnswerVO vo) {
		answerService.updateanswer(vo);
		return "redirect:admin_qna_list";
	}
	
	
}
